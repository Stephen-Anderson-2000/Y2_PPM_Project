package com.example.ppm_project;

import java.io.BufferedReader;


import android.Manifest;
import android.app.Activity;
import android.content.pm.PackageManager;
import android.os.Build;

import androidx.core.app.ActivityCompat;

import java.io.FileReader;

public class ReadCSV {

    public String readFile(String actualFilePath) {
        StringBuilder allData = new StringBuilder();
        if (isReadStoragePermissionGranted()) {
            try {
                String row;
                BufferedReader csvReader = new BufferedReader(new FileReader(actualFilePath));
                while ((row = csvReader.readLine()) != null) {
                    String[] csvData = row.split(",");
                    for(int i = 0; i < csvData.length; i++){
                        allData.append(csvData[i]).append(" ");
                    }
                }
            } catch (java.io.IOException s) {
                System.out.println(s.getMessage());
            }
        }
        return allData.toString();
    }

    public boolean isReadStoragePermissionGranted() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            if (.checkSelfPermission(Manifest.permission.READ_EXTERNAL_STORAGE) ==
                    PackageManager.PERMISSION_GRANTED)
            {

            }
        }
        return false;
    }
}
